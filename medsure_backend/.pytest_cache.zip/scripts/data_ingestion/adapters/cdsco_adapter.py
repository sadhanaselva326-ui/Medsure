"""cdsco_adapter.py - Official CDSCO NSQ & Drug Alert Data Adapter.

Imports verified Not of Standard Quality (NSQ) drug alerts, batch recalls, and
regulatory notices issued by the Central Drugs Standard Control Organisation (CDSCO),
Ministry of Health and Family Welfare, Government of India.
"""

import json
import os
from datetime import datetime, date
from typing import List, Optional

from scripts.data_ingestion.base import BaseSourceImporter, RawMedicineRecord, RawRegulatoryAlert
from scripts.data_ingestion.normalizer import (
    normalize_brand_name,
    normalize_generic_name,
    normalize_manufacturer,
)


class CDSCOAlertAdapter(BaseSourceImporter):
    """Adapter for official CDSCO monthly NSQ (Not of Standard Quality) drug alerts."""

    def __init__(self, data_file_path: Optional[str] = None):
        if data_file_path and os.path.exists(data_file_path):
            self.file_path = data_file_path
        else:
            base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            self.file_path = os.path.join(base_dir, "data", "cdsco_nsq_alerts.json")

    @property
    def source_name(self) -> str:
        return "cdsco_nsq"

    @property
    def source_type(self) -> str:
        return "government"

    @property
    def source_url(self) -> str:
        return "https://cdsco.gov.in"

    async def load_records(self) -> List[RawMedicineRecord]:
        """Alerts are primarily loaded via load_alert_records()."""
        return []

    async def load_alert_records(self) -> List[RawRegulatoryAlert]:
        """Loads and normalizes official CDSCO NSQ alerts from monthly laboratory test lists."""
        if not os.path.exists(self.file_path):
            raise FileNotFoundError(f"CDSCO alert file not found at: {self.file_path}")

        with open(self.file_path, "r", encoding="utf-8") as f:
            raw_data = json.load(f)

        alerts: List[RawRegulatoryAlert] = []
        for item in raw_data:
            dt = date.today()
            if item.get("alert_date"):
                try:
                    dt = datetime.strptime(item["alert_date"], "%Y-%m-%d").date()
                except ValueError:
                    pass

            alert_obj = RawRegulatoryAlert(
                medicine_brand=normalize_brand_name(item.get("medicine_name")),
                generic_name=normalize_generic_name(item.get("generic_name")),
                batch_number=str(item.get("batch_number", "")).strip(),
                manufacturer_name=normalize_manufacturer(item.get("manufacturer")),
                alert_date=dt,
                alert_type="nsq_alert",
                severity=item.get("severity", "high"),
                description=item.get("description", "Not of Standard Quality (NSQ) report issued by CDSCO testing laboratory."),
                reason_for_nsq=item.get("reason_for_nsq"),
                testing_lab=item.get("testing_lab"),
                source_url=self.source_url,
                source_record_id=item.get("alert_code"),
                is_demo=False,
            )
            alerts.append(alert_obj)

        return alerts
