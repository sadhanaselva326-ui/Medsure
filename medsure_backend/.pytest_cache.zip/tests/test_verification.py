import pytest


@pytest.mark.asyncio
async def test_scan_analyze_with_barcode(client):
    payload = {
        "barcode": "8901234001011",
        "extracted_fields": {
            "brand_name": "Dolo",
            "strength": "650mg",
            "batch_number": "DL650201",
            "expiry_date": "2027-08",
        },
    }
    response = await client.post("/api/scan/analyze", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert len(data["matched_medicines"]) >= 1
    matched = data["matched_medicines"][0]
    assert matched["brand_name"] == "Dolo 650"
    assert matched["confidence_score"] == 1.0
    assert "barcode_exact_match" in matched["match_flags"]
    assert data["risk_assessment"]["recommendation"] == "VERIFIED"


@pytest.mark.asyncio
async def test_scan_analyze_with_ocr_text(client):
    payload = {
        "ocr_text": "Dolo 650 Paracetamol IP 650mg Mfg: Micro Labs Batch: DL650201 Exp: 08/2027",
    }
    response = await client.post("/api/scan/analyze", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert len(data["matched_medicines"]) >= 1
    assert data["matched_medicines"][0]["brand_name"] == "Dolo 650"
    assert data["risk_assessment"]["recommendation"] == "VERIFIED"


@pytest.mark.asyncio
async def test_scan_analyze_critical_recall_alert(client):
    # Recall exists on batch 'DL650-RECALL-99'
    payload = {
        "barcode": "8901234001011",
        "extracted_fields": {
            "brand_name": "Dolo",
            "batch_number": "DL650-RECALL-99",
        },
    }
    response = await client.post("/api/scan/analyze", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert len(data["regulatory_alerts"]) >= 1
    assert data["risk_assessment"]["overall_risk"] == "high"
    assert data["risk_assessment"]["recommendation"] == "HIGH_RISK"
    assert "CRITICAL_REGULATORY_RECALL_OR_ALERT" in data["risk_assessment"]["flags"]


@pytest.mark.asyncio
async def test_medicine_verify_strict(client):
    payload = {
        "barcode": "8901234001011",
        "extracted_fields": {
            "brand_name": "Dolo",
            "strength": "650mg",
        },
        "strict_mode": True,
    }
    response = await client.post("/api/medicine/verify", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "VERIFIED"
    assert data["confidence"] == 1.0
    assert data["medicine"]["brand_name"] == "Dolo 650"
