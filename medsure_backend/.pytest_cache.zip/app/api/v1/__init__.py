from fastapi import APIRouter
from app.api.v1.medicines import router as medicines_router
from app.api.v1.manufacturers import router as manufacturers_router
from app.api.v1.alerts import router as alerts_router
from app.api.v1.verification import router as verification_router
from app.api.v1.admin import router as admin_router

v1_router = APIRouter()
v1_router.include_router(medicines_router)
v1_router.include_router(manufacturers_router)
v1_router.include_router(alerts_router)
v1_router.include_router(verification_router)
v1_router.include_router(admin_router)

__all__ = ["v1_router"]
