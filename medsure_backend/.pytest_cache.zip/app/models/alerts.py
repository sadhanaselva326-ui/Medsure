import uuid
from datetime import datetime, timezone, date
from sqlalchemy import (
    Boolean,
    Column,
    Date,
    DateTime,
    ForeignKey,
    Index,
    String,
    Text,
    CheckConstraint,
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.database import Base, GUID


class RegulatoryAlert(Base):
    __tablename__ = "regulatory_alert"

    alert_id = Column(GUID, primary_key=True, default=uuid.uuid4)
    medicine_id = Column(
        GUID,
        ForeignKey("medicine_master.medicine_id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    variant_id = Column(
        GUID,
        ForeignKey("medicine_variant.variant_id", ondelete="SET NULL"),
        nullable=True,
        index=True,
    )
    alert_type = Column(
        String(30),
        CheckConstraint(
            "alert_type IN ('recall', 'advisory', 'quality_alert', 'batch_alert', 'price_violation', 'nsq_alert', 'spurious')",
            name="check_alert_type",
        ),
        nullable=False,
    )
    batch_number = Column(Text, nullable=True, index=True)
    manufacturer = Column(Text, nullable=True)
    alert_date = Column(Date, default=date.today, nullable=False, index=True)
    source_url = Column(Text, nullable=True)
    description = Column(Text, nullable=False)
    reason_for_nsq = Column(Text, nullable=True)  # Specific CDSCO test failure reason
    testing_lab = Column(Text, nullable=True)     # e.g. Central Drugs Laboratory, Kolkata
    severity = Column(
        String(20),
        CheckConstraint(
            "severity IN ('critical', 'high', 'medium', 'low')",
            name="check_alert_severity",
        ),
        default="medium",
        nullable=False,
        index=True,
    )
    is_active = Column(Boolean, default=True, nullable=False, index=True)

    # Source provenance
    source_id = Column(
        GUID,
        ForeignKey("data_source.source_id", ondelete="SET NULL"),
        nullable=True,
    )
    source_name = Column(Text, nullable=True, index=True)
    source_record_id = Column(Text, nullable=True, index=True)
    retrieval_date = Column(DateTime(timezone=True), nullable=True)
    last_verified_at = Column(DateTime(timezone=True), nullable=True)
    is_demo = Column(Boolean, default=False, nullable=False, index=True)

    created_at = Column(
        DateTime(timezone=True),
        default=lambda: datetime.now(timezone.utc),
        server_default=func.now(),
        nullable=False,
    )

    # Relationships
    medicine = relationship("MedicineMaster", back_populates="regulatory_alerts")
    variant = relationship("MedicineVariant", back_populates="regulatory_alerts")
    source = relationship("DataSource", back_populates="regulatory_alerts")

    __table_args__ = (
        Index("idx_alerts_medicine_id", "medicine_id"),
        Index("idx_alerts_batch_num", "batch_number"),
        Index("idx_alerts_alert_date", "alert_date"),
        Index("idx_alerts_severity", "severity"),
        Index("idx_alerts_is_active", "is_active"),
        Index("idx_alerts_is_demo", "is_demo"),
    )
