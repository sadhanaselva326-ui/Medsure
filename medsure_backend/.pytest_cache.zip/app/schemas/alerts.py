from datetime import date, datetime
from typing import Optional
from uuid import UUID
from pydantic import BaseModel, ConfigDict, Field


class RegulatoryAlertBase(BaseModel):
    alert_type: str = Field(
        ...,
        description="Type: recall, advisory, quality_alert, batch_alert, price_violation",
    )
    batch_number: Optional[str] = None
    manufacturer: Optional[str] = None
    alert_date: date = Field(default_factory=date.today)
    source_url: Optional[str] = None
    description: str
    severity: str = Field("medium", description="critical, high, medium, low")
    is_active: bool = True
    medicine_id: Optional[UUID] = None
    variant_id: Optional[UUID] = None
    source_id: Optional[UUID] = None


class RegulatoryAlertCreate(RegulatoryAlertBase):
    pass


class RegulatoryAlertRead(RegulatoryAlertBase):
    model_config = ConfigDict(from_attributes=True)

    alert_id: UUID
    created_at: datetime
    brand_name: Optional[str] = None
    generic_name: Optional[str] = None
