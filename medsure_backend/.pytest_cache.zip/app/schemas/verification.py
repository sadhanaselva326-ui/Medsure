from typing import Any, Dict, List, Optional
from uuid import UUID
from pydantic import BaseModel, Field

from app.schemas.alerts import RegulatoryAlertRead


class ExtractedFields(BaseModel):
    brand_name: Optional[str] = None
    generic_name: Optional[str] = None
    strength: Optional[str] = None
    manufacturer: Optional[str] = None
    batch_number: Optional[str] = None
    expiry_date: Optional[str] = None
    mrp: Optional[float] = None


class ScanAnalyzeRequest(BaseModel):
    ocr_text: Optional[str] = Field(
        None,
        description="Raw OCR text extracted from package or strip",
        examples=["Dolo 650 Paracetamol IP 650mg Mfg: Micro Labs Batch: XYZ123 Exp: 12/2027"],
    )
    barcode: Optional[str] = Field(None, description="13-digit EAN barcode (starts with 890 for India)")
    gtin: Optional[str] = Field(None, description="14-digit Global Trade Item Number")
    extracted_fields: Optional[ExtractedFields] = Field(default_factory=ExtractedFields)


class MatchedMedicineItem(BaseModel):
    medicine_id: UUID
    brand_name: str
    generic_name: str
    strength: Optional[str] = None
    manufacturer: Optional[str] = None
    confidence_score: float
    match_flags: List[str] = Field(default_factory=list)
    source: Optional[str] = None
    mrp: Optional[float] = None
    ceiling_price: Optional[float] = None


class RiskAssessment(BaseModel):
    overall_risk: str = Field(..., description="low, medium, high")
    flags: List[str] = Field(default_factory=list)
    recommendation: str = Field(
        ...,
        description="VERIFIED, NEEDS_VERIFICATION, HIGH_RISK, or NO_MATCH",
    )
    explanation: str


class ScanAnalyzeResponse(BaseModel):
    matched_medicines: List[MatchedMedicineItem] = []
    regulatory_alerts: List[RegulatoryAlertRead] = []
    risk_assessment: RiskAssessment


class MedicineVerifyRequest(ScanAnalyzeRequest):
    strict_mode: bool = Field(True, description="Enforce strict matching on strength and manufacturer")


class MedicineVerifyResponse(BaseModel):
    status: str = Field(
        ...,
        description="VERIFIED, NEEDS_VERIFICATION, HIGH_RISK, or NO_MATCH",
    )
    confidence: float
    medicine: Optional[MatchedMedicineItem] = None
    risk_assessment: RiskAssessment
    regulatory_alerts: List[RegulatoryAlertRead] = []
