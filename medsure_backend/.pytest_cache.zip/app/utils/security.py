import time
from collections import defaultdict
from typing import Dict, List, Optional
from fastapi import HTTPException, Request, Security, status
from fastapi.security import APIKeyHeader

from app.config import settings

api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


class RateLimiter:
    """Sliding-window in-memory rate limiter per IP address."""

    def __init__(self, requests_per_minute: int = 100):
        self.requests_per_minute = requests_per_minute
        self.records: Dict[str, List[float]] = defaultdict(list)

    def check(self, ip: str) -> bool:
        now = time.time()
        window_start = now - 60.0
        # Discard requests outside current 60s window
        valid_requests = [t for t in self.records[ip] if t > window_start]
        self.records[ip] = valid_requests

        if len(valid_requests) >= self.requests_per_minute:
            return False

        self.records[ip].append(now)
        return True


rate_limiter = RateLimiter(requests_per_minute=settings.RATE_LIMIT_PER_MINUTE)


async def verify_admin_key(api_key: Optional[str] = Security(api_key_header)) -> bool:
    """Optional security check for admin endpoints."""
    # If a secret key or ABDM API key is configured, verify it; otherwise allow in debug/demo mode
    if not settings.SECRET_KEY or settings.DEBUG:
        return True
    if api_key == settings.SECRET_KEY or api_key == settings.ABDM_API_KEY:
        return True
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail="Invalid or missing API key for administrative operations.",
    )
