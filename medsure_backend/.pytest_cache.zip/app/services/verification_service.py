import re
from datetime import datetime, date
from typing import Any, Dict, List, Optional, Tuple
from sqlalchemy import select, or_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.codes import MedicineCode
from app.models.medicine import Medicine
from app.models.variant import MedicineVariant
from app.models.manufacturer import Manufacturer
from app.models.sources import DataSource
from app.models.alerts import RegulatoryAlert
from app.schemas.verification import (
    ExtractedFields,
    MatchedMedicineItem,
    RiskAssessment,
    ScanAnalyzeRequest,
    ScanAnalyzeResponse,
    MedicineVerifyRequest,
    MedicineVerifyResponse,
)
from app.schemas.alerts import RegulatoryAlertRead
from app.services.alert_service import get_alerts_for_medicine_or_batch
from app.utils.helpers import (
    calculate_string_similarity,
    normalize_text,
    extract_strength_and_unit,
    clean_salt_name,
)


def parse_ocr_text_to_fields(ocr_text: str, existing_fields: Optional[ExtractedFields] = None) -> ExtractedFields:
    """Extracts structured fields from raw OCR text using regex heuristics."""
    fields = existing_fields.model_copy() if existing_fields else ExtractedFields()

    if not ocr_text:
        return fields

    text = ocr_text.strip()

    # Extract Batch Number: Batch[:\s]+([A-Za-z0-9_-]+) or B.No.[:\s]+
    if not fields.batch_number:
        batch_m = re.search(r"(?:batch|b\.?\s*no\.?)[:\s]+([A-Za-z0-9_-]+)", text, re.IGNORECASE)
        if batch_m:
            fields.batch_number = batch_m.group(1).strip()

    # Extract Expiry: Exp[:\s]+(\d{1,2}[/-]\d{2,4}) or (EXP\.?\s*\d{2}/\d{4}) or YYYY-MM
    if not fields.expiry_date:
        exp_m = re.search(
            r"(?:exp|expiry|exp\.?\s*date)[:\s]+([0-9]{1,2}[/-][0-9]{2,4}|[0-9]{4}[/-][0-9]{1,2})",
            text,
            re.IGNORECASE,
        )
        if exp_m:
            fields.expiry_date = exp_m.group(1).strip()

    # Extract Manufacturer: Mfg[:\s]+(.*?)(?=\s+(?:batch|b\.?\s*no|exp|expiry|mrp|lic|pkg|rs|\$|₹)|$)
    if not fields.manufacturer:
        mfg_m = re.search(
            r"(?:mfg|manufactured\s+by|mkt\s+by)[:\s]+(.*?)(?=\s+(?:batch|b\.?\s*no|exp|expiry|mrp|lic|pkg|rs|\$|₹)|$)",
            text,
            re.IGNORECASE,
        )
        if mfg_m and mfg_m.group(1).strip():
            fields.manufacturer = mfg_m.group(1).strip()
        else:
            mfg_fallback = re.search(r"(?:mfg|manufactured\s+by|mkt\s+by)[:\s]+([^,\n\r]+)", text, re.IGNORECASE)
            if mfg_fallback:
                fields.manufacturer = mfg_fallback.group(1).strip()

    # Extract Strength: e.g. 650mg, 500 mg, 10mg
    if not fields.strength:
        val, unit = extract_strength_and_unit(text)
        if val and unit:
            fields.strength = f"{val} {unit}"

    # Extract Brand / Generic if not present
    if not fields.brand_name:
        pre_mfg = re.split(r"(?:mfg|manufactured|mkt|batch|exp|b\.no)", text, flags=re.IGNORECASE)[0].strip()
        tokens = pre_mfg.split()
        if len(tokens) >= 2 and tokens[1].isdigit():
            fields.brand_name = f"{tokens[0]} {tokens[1]}"
        elif tokens:
            fields.brand_name = tokens[0]

    return fields


def check_is_expired(expiry_str: Optional[str]) -> bool:
    """Checks whether the expiry date string indicates an expired product."""
    if not expiry_str:
        return False
    clean = expiry_str.strip()
    today = date.today()
    try:
        # Format MM/YYYY or MM-YYYY or YYYY-MM or YYYY/MM
        if "/" in clean or "-" in clean:
            sep = "/" if "/" in clean else "-"
            parts = clean.split(sep)
            if len(parts) == 2:
                if len(parts[0]) == 4:
                    year = int(parts[0])
                    month = int(parts[1])
                else:
                    month = int(parts[0])
                    year = int(parts[1])
                if year < 100:
                    year += 2000
                return (year < today.year) or (year == today.year and month < today.month)
            elif len(parts) == 3:
                # DD/MM/YYYY or YYYY/MM/DD
                if len(parts[0]) == 4:
                    year, month, day = int(parts[0]), int(parts[1]), int(parts[2])
                else:
                    day, month, year = int(parts[0]), int(parts[1]), int(parts[2])
                if year < 100:
                    year += 2000
                return date(year, month, day) < today
    except Exception:
        pass
    return False


async def analyze_scan_or_query(
    session: AsyncSession,
    payload: ScanAnalyzeRequest,
) -> ScanAnalyzeResponse:
    """Core verification and risk assessment logic.

    Matches against barcode/GTIN, fuzzy name/strength/composition, evaluates regulatory
    alerts, manufacturer status, pricing, and returns recommendation.
    """
    extracted = parse_ocr_text_to_fields(payload.ocr_text, payload.extracted_fields)
    barcode = payload.barcode.strip() if payload.barcode else None
    gtin = payload.gtin.strip() if payload.gtin else None

    matched_medicines: List[MatchedMedicineItem] = []
    match_flags: List[str] = []
    confidence = 0.0
    primary_medicine: Optional[Medicine] = None
    primary_variant: Optional[MedicineVariant] = None

    # Step 1: Exact lookup on GTIN / Barcode
    if gtin or barcode:
        code_stmt = (
            select(MedicineCode)
            .options(
                selectinload(MedicineCode.variant)
                .selectinload(MedicineVariant.medicine)
                .selectinload(Medicine.source),
                selectinload(MedicineCode.variant).selectinload(MedicineVariant.manufacturer),
            )
            .where(
                or_(
                    MedicineCode.gtin == (gtin or barcode),
                    MedicineCode.barcode == (barcode or gtin),
                    MedicineCode.identifier_value == (barcode or gtin),
                )
            )
        )
        code_res = await session.execute(code_stmt)
        code_obj = code_res.scalars().first()

        if code_obj and code_obj.variant and code_obj.variant.medicine:
            primary_variant = code_obj.variant
            primary_medicine = primary_variant.medicine
            confidence = 1.0
            match_flags.append("barcode_exact_match" if barcode else "gtin_exact_match")

            # Check secondary flags
            if extracted.brand_name and normalize_text(extracted.brand_name) in normalize_text(primary_medicine.brand_name):
                match_flags.append("name_match")
            if extracted.strength and primary_medicine.strength and normalize_text(extracted.strength) in normalize_text(primary_medicine.strength):
                match_flags.append("strength_match")

    # Step 2: If no GTIN match, fuzzy match on brand_name, generic_name, strength, or OCR text
    if not primary_medicine and (extracted.brand_name or extracted.generic_name or payload.ocr_text):
        search_brand = extracted.brand_name or ""
        search_generic = extracted.generic_name or ""
        norm_ocr = normalize_text(payload.ocr_text) if payload.ocr_text else ""

        # Fetch candidate medicines
        cand_stmt = (
            select(Medicine)
            .options(
                selectinload(Medicine.variants).selectinload(MedicineVariant.manufacturer),
                selectinload(Medicine.source),
            )
            .where(Medicine.is_discontinued == False)
        )
        cand_res = await session.execute(cand_stmt)
        all_candidates = cand_res.scalars().all()

        best_score = 0.0
        best_cand: Optional[Medicine] = None
        best_flags: List[str] = []

        for cand in all_candidates:
            current_score = 0.0
            cand_flags = []
            cand_brand_norm = normalize_text(cand.brand_name)
            cand_gen_norm = normalize_text(clean_salt_name(cand.generic_name) or cand.generic_name)

            # Brand similarity
            if cand_brand_norm and norm_ocr and cand_brand_norm in norm_ocr:
                sim_b = 1.0
            else:
                sim_b = calculate_string_similarity(search_brand, cand.brand_name) if search_brand else 0.0

            # Generic similarity
            if cand_gen_norm and norm_ocr and cand_gen_norm in norm_ocr:
                sim_g = 1.0
            else:
                sim_g = calculate_string_similarity(search_generic, cand.generic_name) if search_generic else 0.0

            if sim_b >= 0.8:
                current_score += 0.55
                cand_flags.append("name_match")
            elif sim_b >= 0.5:
                current_score += 0.35
                cand_flags.append("name_fuzzy_match")

            if sim_g >= 0.8:
                current_score += 0.30
                cand_flags.append("composition_match")
            elif sim_g >= 0.5:
                current_score += 0.15
                cand_flags.append("composition_partial_match")

            # Strength match
            cand_str_norm = normalize_text(cand.strength or "")
            if cand_str_norm and norm_ocr and cand_str_norm in norm_ocr:
                current_score += 0.15
                cand_flags.append("strength_match")
            elif extracted.strength and cand.strength:
                val1, _ = extract_strength_and_unit(extracted.strength)
                val2, _ = extract_strength_and_unit(cand.strength)
                if val1 and val2 and val1 == val2:
                    current_score += 0.15
                    cand_flags.append("strength_match")

            # Manufacturer match
            if cand.variants:
                for v in cand.variants:
                    if v.manufacturer:
                        mfg_norm = normalize_text(v.manufacturer.name)
                        if (norm_ocr and mfg_norm in norm_ocr) or (extracted.manufacturer and calculate_string_similarity(extracted.manufacturer, v.manufacturer.name) > 0.6):
                            cand_flags.append("manufacturer_match")
                            current_score += 0.05
                            break

            current_score = min(1.0, current_score)

            if current_score > best_score:
                best_score = current_score
                best_cand = cand
                best_flags = cand_flags

        if best_cand and best_score >= 0.5:
            primary_medicine = best_cand
            confidence = round(best_score, 2)
            match_flags = best_flags
            if primary_medicine.variants:
                primary_variant = primary_medicine.variants[0]

    # Build matched medicine item if found
    if primary_medicine:
        mfg_name = (
            primary_variant.manufacturer.name
            if primary_variant and primary_variant.manufacturer
            else None
        )
        mrp_val = float(primary_variant.mrp) if primary_variant and primary_variant.mrp is not None else None
        ceiling_val = float(primary_variant.ceiling_price) if primary_variant and primary_variant.ceiling_price is not None else None

        matched_medicines.append(
            MatchedMedicineItem(
                medicine_id=primary_medicine.medicine_id,
                brand_name=primary_medicine.brand_name,
                generic_name=primary_medicine.generic_name,
                strength=primary_medicine.strength,
                manufacturer=mfg_name,
                confidence_score=confidence,
                match_flags=match_flags,
                source=primary_medicine.source_name or (primary_medicine.source.source_name if primary_medicine.source else "medsure_db"),
                mrp=mrp_val,
                ceiling_price=ceiling_val,
            )
        )

    # Step 3: Check regulatory alerts on medicine, variant, batch, or manufacturer
    regulatory_alerts = await get_alerts_for_medicine_or_batch(
        session=session,
        medicine_id=primary_medicine.medicine_id if primary_medicine else None,
        variant_id=primary_variant.variant_id if primary_variant else None,
        batch_number=extracted.batch_number,
        manufacturer=extracted.manufacturer or (primary_variant.manufacturer.name if primary_variant and primary_variant.manufacturer else None),
        active_only=True,
        for_scan=True,
    )

    # Step 4: Risk assessment
    risk_flags: List[str] = []
    has_critical_alert = any(a.severity == "critical" or a.alert_type == "recall" for a in regulatory_alerts)
    has_alert = len(regulatory_alerts) > 0

    if has_critical_alert:
        risk_flags.append("CRITICAL_REGULATORY_RECALL_OR_ALERT")
    elif has_alert:
        risk_flags.append("REGULATORY_ALERT_PRESENT")

    # Expiry check
    if extracted.expiry_date and check_is_expired(extracted.expiry_date):
        risk_flags.append("EXPIRED_PRODUCT")

    # Manufacturer verification status
    mfg_status = "unverified"
    if primary_variant and primary_variant.manufacturer:
        mfg_status = primary_variant.manufacturer.verification_status
        if mfg_status != "verified":
            risk_flags.append(f"MANUFACTURER_{mfg_status.upper()}")

    # Price deviation check (>20% higher than NPPA ceiling or MRP)
    if extracted.mrp and primary_variant:
        ref_price = float(primary_variant.ceiling_price or primary_variant.mrp or 0.0)
        if ref_price > 0 and extracted.mrp > ref_price * 1.2:
            risk_flags.append("PRICE_DEVIATION_HIGH")

    # Decide recommendation and overall risk
    if has_critical_alert or "EXPIRED_PRODUCT" in risk_flags:
        overall_risk = "high"
        recommendation = "HIGH_RISK"
        explanation = (
            f"High risk detected: {', '.join(risk_flags)}. "
            "Active critical regulatory recall or advisory notice matches this batch/product."
        )
    elif not primary_medicine or confidence < 0.5:
        if has_alert:
            overall_risk = "high"
            recommendation = "HIGH_RISK"
            explanation = "No matching catalogue record, but Regulatory Alert Found for this batch."
        else:
            overall_risk = "high"
            recommendation = "NO_MATCH"
            explanation = "No matching catalogue record found in the authoritative database."
    elif has_alert:
        overall_risk = "high"
        recommendation = "HIGH_RISK"
        explanation = "Catalogue Match found, but Regulatory Alert Found for this medicine/batch."
    elif confidence >= 0.90 and len(risk_flags) == 0:
        overall_risk = "low"
        source_name = primary_medicine.source_name or (primary_medicine.source.source_name if primary_medicine.source else "master database")
        recommendation = "VERIFIED"
        explanation = f"Catalogue Match with official record from {source_name}. No matching regulatory alert found."
    else:
        overall_risk = "medium"
        recommendation = "NEEDS_VERIFICATION"
        reasons = risk_flags if risk_flags else ["confidence score below verified threshold"]
        explanation = f"Product needs manual verification: {', '.join(reasons)}."

    return ScanAnalyzeResponse(
        matched_medicines=matched_medicines,
        regulatory_alerts=regulatory_alerts,
        risk_assessment=RiskAssessment(
            overall_risk=overall_risk,
            flags=risk_flags,
            recommendation=recommendation,
            explanation=explanation,
        ),
    )


async def verify_medicine_strict(
    session: AsyncSession,
    payload: MedicineVerifyRequest,
) -> MedicineVerifyResponse:
    """Strict verification returning explicit status and confidence."""
    analysis = await analyze_scan_or_query(session, payload)
    first_med = analysis.matched_medicines[0] if analysis.matched_medicines else None
    confidence = first_med.confidence_score if first_med else 0.0

    return MedicineVerifyResponse(
        status=analysis.risk_assessment.recommendation,
        confidence=confidence,
        medicine=first_med,
        risk_assessment=analysis.risk_assessment,
        regulatory_alerts=analysis.regulatory_alerts,
    )
