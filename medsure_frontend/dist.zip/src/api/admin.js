import { request } from './client';

export const adminApi = {
  /**
   * Get official database stats directly from PostgreSQL master tables
   */
  getSystemStats: async () => {
    return request('/api/admin/stats');
  },

  /**
   * Health check endpoint
   */
  getHealth: async () => {
    return request('/health');
  },

  /**
   * Data sources overview
   */
  getDataSources: async () => {
    return request('/api/admin/sources');
  }
};
