import React from 'react';
import { ShieldAlert } from 'lucide-react';

export const DisclaimerBanner = ({ style = {} }) => {
  return (
    <aside className="disclaimer-banner" style={style} aria-label="Product positioning disclaimer">
      <ShieldAlert size={18} style={{ color: 'var(--color-primary-dark)', flexShrink: 0, marginTop: '2px' }} />
      <div>
        <strong>MedSure Vision Disclaimer:</strong> MedSure Vision is an AI-assisted first-line screening and risk-flagging tool. It evaluates consistency against available master records and does not certify 100% authenticity. Always verify with licensed pharmacists or standard chemical laboratory assays for critical medical decisions.
      </div>
    </aside>
  );
};
