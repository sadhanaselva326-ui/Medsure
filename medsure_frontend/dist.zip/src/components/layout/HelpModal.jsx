import React from 'react';
import { X, ShieldCheck, AlertTriangle, XCircle, HelpCircle, CheckCircle } from 'lucide-react';
import { Button } from '../common/Button';

export const HelpModal = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose} role="dialog" aria-modal="true" aria-labelledby="help-title">
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.625rem' }}>
            <ShieldCheck size={24} style={{ color: 'var(--color-primary)' }} />
            <h2 id="help-title" style={{ fontFamily: 'var(--font-family-brand)', fontSize: '1.25rem' }}>
              MedSure Vision Screening Guide
            </h2>
          </div>
          <button onClick={onClose} aria-label="Close modal" style={{ padding: '0.375rem', borderRadius: '50%' }}>
            <X size={20} />
          </button>
        </div>

        <div className="modal-body" style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          <div>
            <h4 style={{ fontWeight: 700, marginBottom: '0.375rem', color: 'var(--color-primary-dark)' }}>
              First-Line Screening Principles
            </h4>
            <p style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)' }}>
              MedSure Vision cross-references Indian drug master databases (including CDSCO, NPPA, GS1, and Kaggle master records comprising over 247,000 medicines) to flag discrepancies in packaging, dosage forms, manufacturer claims, and recalled batches.
            </p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
            <h4 style={{ fontWeight: 700, fontSize: '0.9375rem' }}>Screening Result Categories:</h4>

            <div style={{ display: 'flex', gap: '0.75rem', padding: '0.75rem', borderRadius: 'var(--radius-md)', background: 'var(--color-success-bg)', border: '1px solid var(--color-success-border)' }}>
              <CheckCircle size={20} style={{ color: 'var(--color-success)', flexShrink: 0, marginTop: '2px' }} />
              <div>
                <div style={{ fontWeight: 700, color: 'var(--color-success)', fontSize: '0.875rem' }}>Consistent with Records</div>
                <div style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>Brand name, generic formulation, strength, and manufacturer match registered master catalog data.</div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', padding: '0.75rem', borderRadius: 'var(--radius-md)', background: 'var(--color-warning-bg)', border: '1px solid var(--color-warning-border)' }}>
              <AlertTriangle size={20} style={{ color: 'var(--color-warning)', flexShrink: 0, marginTop: '2px' }} />
              <div>
                <div style={{ fontWeight: 700, color: 'var(--color-warning)', fontSize: '0.875rem' }}>Further Verification Needed</div>
                <div style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>Image was blurry, text partially obscured, or batch number is not tracked in the public registry.</div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', padding: '0.75rem', borderRadius: 'var(--radius-md)', background: 'var(--color-danger-bg)', border: '1px solid var(--color-danger-border)' }}>
              <XCircle size={20} style={{ color: 'var(--color-danger)', flexShrink: 0, marginTop: '2px' }} />
              <div>
                <div style={{ fontWeight: 700, color: 'var(--color-danger)', fontSize: '0.875rem' }}>Potential Mismatch Detected</div>
                <div style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>Strength discrepancy, unregistered manufacturer name, price ceiling violation, or active recall detected.</div>
              </div>
            </div>

            <div style={{ display: 'flex', gap: '0.75rem', padding: '0.75rem', borderRadius: 'var(--radius-md)', background: 'var(--color-bg-subtle)', border: '1px solid var(--color-border)' }}>
              <HelpCircle size={20} style={{ color: 'var(--color-text-subtle)', flexShrink: 0, marginTop: '2px' }} />
              <div>
                <div style={{ fontWeight: 700, color: 'var(--color-text-subtle)', fontSize: '0.875rem' }}>No Matching Record Found</div>
                <div style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>Medicine brand or formulation could not be found in the current master catalogue.</div>
              </div>
            </div>
          </div>

          <div style={{ background: '#f8fafc', padding: '0.75rem', borderRadius: 'var(--radius-md)', fontSize: '0.8125rem', color: 'var(--color-text-subtle)' }}>
            <strong>Important Regulatory Contact:</strong> If you suspect counterfeit or substandard drugs, report directly to the Central Drugs Standard Control Organisation (CDSCO) or your State Drug Controller.
          </div>
        </div>

        <div className="modal-footer">
          <Button variant="primary" onClick={onClose}>
            Got it, thanks
          </Button>
        </div>
      </div>
    </div>
  );
};
